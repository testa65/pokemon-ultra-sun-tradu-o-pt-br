# Como contribuir

Contribuições são bem-vindas — correções de tradução, revisão de consistência,
melhorias nas ferramentas, ou a sua própria variante da tradução.

## Preparar o ambiente

1. Tenha **Python 3** instalado.
2. Faça um dump **do seu próprio** Ultra Sun, descriptografado (`.3ds`/`.cci`/`.cia`).
3. Extraia os originais e (opcional) o texto em inglês de referência:

   ```bash
   python tools/extrair_originais.py "seu_dump.3ds" --ingles
   ```

   Isso cria `build/orig/*.garc` e `extraido/{gametext_en,storytext_en}/`.
   Esses arquivos são do jogo — o `.gitignore` já os mantém fora do repositório.

## Editar a tradução

- Edite os `.txt` em `traducao/gametext/` e `traducao/storytext/`.
- **Regras que não podem ser quebradas** (detalhe em `docs/COMO_TRADUZIR.md`):
  - **uma linha do arquivo = uma linha no jogo** — não apague nem crie linhas;
  - **não altere** nada entre colchetes: `[VAR ...]`, `[WAIT n]`, `[~ n]`;
  - **não altere** os códigos `\n` (quebra), `\r`, `\c` (pausa/limpa a caixa);
  - salve em **UTF-8**.
- Consulte `docs/MAPA_ARQUIVOS.md` para saber o que é cada subarquivo e
  `docs/REGRAS_STORY.md` para os termos padronizados (nomes de tipos, naturezas,
  jargão de batalha etc.).

## Verificar e montar

```bash
python tools/build_patch.py --so-checar   # só confere (linhas + estouro de caixa)
python tools/build_patch.py               # confere e monta o patch
```

O verificador aponta linhas que podem **estourar a caixa de texto**. Se você
analisou uma e decidiu que cabe, registre em `traducao/aceito.txt`
(`<pasta> <subarquivo>  # motivo`) para silenciar o aviso.

## Mandar a melhoria

- Faça um fork, crie um branch, commite **só** os arquivos de `traducao/`,
  `tools/` ou `docs/` que você mudou, e abra um Pull Request.
- **Nunca** inclua ROMs, `.garc`, `code.bin` ou o conteúdo de `extraido/` no
  commit (o `.gitignore` já protege isso — não force).

## (Opcional) Reconstruir a ROM .3ds/.cia

Para gerar um jogo traduzido a partir do **seu** dump descriptografado:

```bash
# 1) monte o patch (gera LayeredFS/.../romfs/a/0/3/2 e a/0/4/2)
python tools/build_patch.py

# 2) copie o seu dump (trabalhe SEMPRE numa cópia, nunca no original)
#    e substitua os dois arquivos dentro dele, recalculando os hashes:
python tools/ncch_patch.py patch "COPIA_do_seu_jogo.3ds" 0x4000 \
    a/0/3/2=LayeredFS/00040000001B5000/romfs/a/0/3/2 \
    a/0/4/2=LayeredFS/00040000001B5000/romfs/a/0/4/2

# 3) para gerar um .cia a partir do .3ds ja traduzido:
python tools/cci2cia.py "COPIA_do_seu_jogo.3ds" "seu_dump_original.cia" "saida.cia"
```

`ncch_patch.py verify <arquivo> 0x4000` confere a árvore de hashes do RomFS. As
assinaturas de um `.cia` reconstruído ficam inválidas — isso é normal e o Luma
(sigpatches) / FBI aceitam. A ROM gerada é **sua** e não deve ser redistribuída;
divulgue **o patch**, não a ROM.
