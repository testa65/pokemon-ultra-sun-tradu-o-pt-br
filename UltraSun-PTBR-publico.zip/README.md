# Pokémon Ultra Sun — Tradução PT-BR

Tradução para **português brasileiro** de *Pokémon Ultra Sun* (Nintendo 3DS),
aplicada via **LayeredFS** (Luma3DS no console) ou pelo emulador **Azahar**.

Todo o texto do jogo — interface, menus, descrições, diálogos, narração e
história — está traduzido: **~53 mil linhas** em 127 + 1124 subarquivos. Nomes
próprios (Pokémon, golpes, habilidades, personagens, locais e facções) ficam em
inglês, seguindo a convenção da comunidade.

Este repositório traz **as ferramentas e os textos** para você aplicar,
revisar ou **fazer a sua própria versão**. Ele **não** contém — e não pode
conter — a ROM nem nenhum arquivo original do jogo (veja `AVISO_LEGAL.md`).

## O que tem aqui

```
├── tools/            ferramentas em Python (build, codec, extração, patch de ROM)
│   └── dev/          scripts de referência usados uma vez (não precisa mexer)
├── traducao/         AS TRADUÇÕES (é isto que você edita)
│   ├── gametext/     → romfs/a/0/3/2  (interface, menus, descrições)
│   ├── storytext/    → romfs/a/0/4/2  (diálogos, narração, história)
│   ├── itens_dic.json / itens_plural_exc.json   dicionário de itens
│   └── aceito.txt    avisos de estouro de caixa já analisados e aceitos
├── docs/             guias (como traduzir, regras, mapa dos arquivos)
├── build/orig/       ONDE VOCÊ COLOCA os originais do seu dump (vazio no repo)
├── LICENSE           GPLv3
└── AVISO_LEGAL.md    o que pode e o que não pode compartilhar
```

## Pré-requisitos

- **Python 3** (só a biblioteca padrão, nada de instalar pacote).
- Um **dump do seu próprio cartucho/instalação** de Ultra Sun, já
  **descriptografado** (.3ds/.cci ou .cia). Isso não é fornecido aqui.

## Uso rápido — montar o patch

```bash
# 1) extrair os dois arquivos de texto do SEU dump para build/orig/
python tools/extrair_originais.py "caminho/do/seu/Pokemon Ultra Sun.3ds"

# 2) montar o patch (confere contagem de linhas e estouro de caixa)
python tools/build_patch.py
```

O patch sai em `LayeredFS/00040000001B5000/romfs/`. O build é **reproduzível**:
os mesmos textos geram sempre os mesmos GARCs.

## Como aplicar

**Azahar (emulador):** copie a pasta `romfs` para

```
%APPDATA%\Azahar\load\mods\00040000001B5000\
```

**Console com Luma3DS (LayeredFS):** copie para o SD, no cartão:

```
/luma/titles/00040000001B5000/romfs/
```

e ative "Enable game patching" no menu do Luma (SELECT no boot).

## Fazer a sua própria versão / contribuir

É só editar os `.txt` em `traducao/` e rodar `build_patch.py` de novo. As regras
de edição (o que não pode mexer, como funcionam as caixas de texto e as
variáveis) estão em **`docs/COMO_TRADUZIR.md`**, **`docs/MAPA_ARQUIVOS.md`** e
**`docs/REGRAS_STORY.md`**. Para mandar melhorias de volta, veja
**`CONTRIBUTING.md`**.

## (Opcional) Reconstruir a ROM .3ds/.cia

Para gerar um `.3ds`/`.cia` já traduzido a partir do **seu** dump (útil pra
rodar no Azahar sem mexer em pasta de mods), veja `CONTRIBUTING.md` — a seção
"Reconstruir a ROM" usa `tools/ncch_patch.py` e `tools/cci2cia.py`. A ROM gerada
fica **na sua máquina** e nunca deve ser redistribuída.

## Licença

Ferramentas e textos de tradução sob **GPLv3** (veja `LICENSE`). *Pokémon*,
*Ultra Sun* e todo o conteúdo original são marcas e propriedade da
Nintendo / Game Freak / The Pokémon Company — este é um projeto de fã, sem fins
lucrativos e sem qualquer vínculo com essas empresas.
