# Como traduzir / revisar

Pipeline completo, roda na sua máquina. Só precisa de **Python 3**.

## Estrutura

```
UltraSun_PTBR/
├── tools/          ferramentas (não precisa mexer)
│   └── dev/        scripts de referência (busca, geração de dicionário…)
├── build/orig/     você coloca aqui os originais do SEU dump (a_0_3_2/a_0_4_2.garc)
├── traducao/       AS TRADUÇÕES — é isto que você edita
│   ├── gametext/       → romfs/a/0/3/2 (interface, nomes, descrições)
│   ├── storytext/      → romfs/a/0/4/2 (diálogos, narração, história)
│   └── aceito.txt      avisos de estouro que você já analisou e aceitou
├── extraido/       (opcional) texto original em inglês, como referência
└── LayeredFS/      o patch montado (saída)
```

A tradução **já está completa** — os `.txt` em `traducao/` são a versão final.
Você edita esses arquivos direto para revisar ou fazer a sua própria versão.

## 0. Pegar os originais (uma vez)

O texto do jogo em si não vem no repositório. Extraia do **seu** dump
descriptografado. O `--ingles` também gera a referência em inglês:

```
python tools/extrair_originais.py "seu_dump.3ds" --ingles
```

## 1. Achar a cena que você quer mexer

Com o inglês de referência extraído (`extraido/`), dá pra buscar por trecho:

```
cd tools/dev
python buscar.py Kukui
python buscar.py "moving to Alola" --contexto 2
python buscar.py Kukui --pasta storytext_en
```

Ele diz o arquivo e a linha. Ex: `[storytext_en/0431.txt] linha 12` → edite o
`traducao/storytext/0431.txt` correspondente.

## 2. Editar

Edite o `.txt` em `traducao/` **linha por linha**.

**Duas regras que não podem ser quebradas:**

1. **A contagem de linhas tem que ser idêntica** à do original. Uma linha do
   original = uma linha da tradução. Linha vazia continua vazia. Não junte nem
   quebre.
2. **Códigos de controle são preservados exatamente**, inclusive a posição.

### Códigos de controle

| Código | O que é |
|---|---|
| `\n` | quebra de linha dentro da caixa |
| `\r` | espera o botão e rola o texto |
| `\c` | espera o botão e limpa a caixa (nova "página") |
| `[VAR 0102(0000)]` | nome de Pokémon, treinador, item… inserido em tempo real |
| `[WAIT 20]` | pausa dramática |
| `[~ 5]` | linha vazia/reservada — **deixe exatamente como está** |
| `\\` `\[` | barra e colchete literais |

Se um `[VAR ...]` aparece no meio da frase, ele precisa continuar fazendo
sentido em português. Às vezes você vai precisar reordenar a frase inteira em
volta dele — isso é normal e é o trabalho.

## 3. Conferir antes de montar

```
python tools/build_patch.py --so-checar
```

Ele valida contagem de linhas e avisa quais frases podem **estourar a caixa de
texto**. Português corre ~20% mais longo que inglês, então isso acontece muito.
O orçamento é calculado por tela, usando o inglês original como régua (se o
original coube no jogo, aquele é o limite real).

Se você analisar um aviso e concluir que cabe mesmo assim, registre em
`traducao/aceito.txt` (`<pasta> <subarquivo>  # motivo`) para ele parar de avisar.

## 4. Montar e instalar

```
python tools/build_patch.py
```

O build é reproduzível: os mesmos textos geram sempre o mesmo GARC. Depois copie
a pasta `LayeredFS/00040000001B5000/romfs` para:

```
%APPDATA%\Azahar\load\mods\00040000001B5000\
```

Em 3DS real com Luma3DS, o caminho equivalente é
`/luma/titles/00040000001B5000/romfs/` (com "Enable game patching" ligado).

## Glossário já fixado

Mantenha para não ficar inconsistente:

| Inglês | PT-BR |
|---|---|
| Bag | Mochila |
| Party | Equipe (rótulo curto: Time) |
| Box | Caixa |
| Berries | Frutas |
| TMs | MTs |
| Key Items | Itens-Chave |
| Lv. | Nv. |
| Ride Pokémon | Pokémon de Montaria (curto: Montaria) |
| Festival Plaza | Praça Festival |
| Festival Coins | Moedas Festival (FC) |
| Characteristic | Característica |
| Date Met | Conhecido em |
| Egg Hatched | Ovo chocou |
| HP / Attack / Defense | HP / Ataque / Defesa |
| Sp. Atk / Sp. Def / Speed | Atq. Esp. / Def. Esp. / Velocidade |
| Pokémon Nursery | Berçário Pokémon |
| Battle Video | Vídeo de Batalha |

**Ficam em inglês:** nomes de Pokémon, golpes, habilidades, treinadores, e os
serviços online (GTS, Battle Spot, Wonder Trade).

Tipos e naturezas já estão traduzidos — veja `traducao/gametext/0112.txt` e
`0092.txt` e siga os mesmos termos. Mais termos padronizados da história em
`docs/REGRAS_STORY.md`.
