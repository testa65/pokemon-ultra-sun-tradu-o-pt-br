# Mapa dos arquivos de texto

O texto do jogo vive em dois arquivos GARC, e cada um é uma coleção de
"subarquivos" numerados. As suas traduções ficam em `traducao/`, um `.txt` por
subarquivo, com o número no nome (ex.: `0038.txt`):

- **`traducao/gametext/`** → vira `romfs/a/0/3/2` — interface, menus, diálogos
  principais, descrições (127 subarquivos).
- **`traducao/storytext/`** → vira `romfs/a/0/4/2` — falas de NPC, narração de
  batalha e textos de história (1124 subarquivos).

Regras de edição (valem sempre): veja `docs/COMO_TRADUZIR.md`. Em resumo: uma
linha do arquivo = uma linha no jogo (não some nem crie linhas), e **não mexa**
no que está entre colchetes `[VAR ...]`, `[WAIT n]`, `[~ n]`, nem em `\n \r \c`.

Depois de editar, rode `python tools/build_patch.py` — ele confere contagem de
linhas e estouro de caixa e remonta os GARCs.

Esta tradução já está **completa**. A tabela abaixo é um guia de referência de
onde está cada tipo de texto em `traducao/gametext/`, útil se você quiser revisar
ou fazer a sua própria versão de uma parte específica.

## Diálogo e narração
| Subarquivo | O que é |
|---|---|
| 0013 | Narração de batalha ("O X selvagem usou Y!" e afins) |
| 0014 | Narração de batalha — versão dos golpes-Z |
| 0015 | Mensagens de status ("X se recuperou!", envenenado, dormindo…) |
| 0017 | Narração de encontro e captura ("Um X selvagem apareceu!") |
| 0020 | Dica do Kukui sobre enfraquecer antes de capturar |
| 0022 | Transições de cena e Ultra Beasts ("No dia seguinte…", codinomes) |
| 0038 | Diálogo (1) |
| 0046 | Diálogo (2) |
| 0048 | Quiz de personalidade (define a natureza) |
| 0076 | Falas do Rotom Dex |
| 0077 | Rotom Dex (modo foto) |
| 0089 | Diálogo (3) |
| 0090 | Falas do lutador (Masked Royal) |
| 0103 | Diálogo (4) |
| 0109 | Falas dos treinadores (antes/depois da batalha) |
| 0126 | Diálogo (5) |

## Textos descritivos
| Subarquivo | O que é |
|---|---|
| 0039 | Descrição de cada item |
| 0102 | Descrição das habilidades |
| 0114 | Descrição dos golpes em concursos |
| 0117 | Descrição dos golpes (efeito) |
| 0121 | Categorias de espécie ("Pokémon Semente", "Pokémon Chama"…) |
| 0124 | Entradas da Pokédex (versão 1) |
| 0125 | Entradas da Pokédex (versão 2) |

## Dados/nomes mantidos em inglês (convenção)
Por convenção da comunidade, nomes próprios ficam em inglês e alguns subarquivos
são só dados: 0000, 0019 (golpes-Z), 0023, 0035, 0036, 0060 (espécies), 0070
(frutas), 0072 (locais de captura), 0091 (nomes Battle Royal), 0096
(créditos/staff), 0101 (habilidades), 0104 (nomes Battle Tree), 0110
(treinadores), 0113, 0118 (golpes), 0119 (formas), 0120, 0122. Também ficam em
inglês: nomes de Pokémon, golpes, habilidades, personagens (Kukui, Lillie,
Hau…), locais e facções (Team Skull, Aether…).
