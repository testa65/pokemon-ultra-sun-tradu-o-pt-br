# Regras de tradução — storytext de Pokémon Ultra Sun (EN → PT-BR)

Você traduz falas da HISTÓRIA do jogo (cutscenes, NPCs do mapa, Hau, Lillie, Kukui, Gladion, Lusamine, Team Skull, etc.).

## Formato (ABSOLUTO — errar corrompe o jogo)
- O arquivo tem blocos `### FILE NNNN`. Copie cada linha `### FILE NNNN` IDÊNTICA.
- Cada outra linha = UMA fala. Uma linha de entrada = UMA linha de saída, na mesma ordem. Nunca junte nem divida linhas. Mesmo número total de linhas.
- Linhas que são só `[~ N]` (referência): copie idênticas.
- Preserve EXATAMENTE (caractere por caractere), sem traduzir nem remover: `[VAR ...]`, `[WAIT n]`, `[~ n]`. Em especial `[VAR 0114(xxxx)]` no fim das falas (retrato/animação do personagem) — sempre no fim, igual ao original.
- `\n` (quebra), `\r` (rola texto) e `\c` (nova caixa) são sequências literais de 2 caracteres. Mantenha `\r` e `\c` na mesma quantidade e ordem; `\n` pode ser reposicionado para equilibrar as linhas.
- Largura: cada linha visual (entre `\n`/`\r`/`\c`) com no máximo ~48 caracteres; no máximo 2 linhas por caixa (use `\c` do original para dividir caixas; não crie `\c` novos).

## Condicionais de gênero/quantidade
Aparecem como `{{1100:COND|masculino|feminino}}` ou `{{1101:COND|singular|plural}}`.
- Mantenha `1100:COND` / `1101:COND` exatamente como vieram. Traduza as duas formas.
- O texto dentro das chaves é o que MUDA; o de fora é comum às duas formas. Você pode reescrever a frase livremente e mover palavras pra dentro ou fora das chaves (ex.: `Show h{{1100:00FF|im|er}} your power` → `Mostre {{1100:00FF|a ele|a ela}} o seu poder`).
- Pode usar a mesma condicional mais de uma vez na linha.
- `1100:00FF` = gênero do JOGADOR. Você PODE ADICIONAR `{{1100:00FF|masc|fem}}` quando um adjetivo/substantivo se refere ao jogador e muda em PT (ex.: "Are you ready?" → `Tá {{1100:00FF|pronto|pronta}}?`). Use só quando necessário.
- Nunca use `|` ou `}` fora dessas chaves.

## Idioma
- Português do BRASIL, informal e natural de videogame. PROIBIDO português de Portugal: nada de "miúdo", "rapariga", "fixe", "autocarro", "tu estás/tens", "pá".
- Jogador = "você" (personagens descontraídos podem usar "cê").
- "kid" → "garoto/moleque" (ou `{{1100:00FF|garoto|garota}}`). Kukui chama o jogador de "cousin" → "primo" (bordão dele); "Woo!" pode ficar.
- Rotom Dex fala com "zzt"/"zzz" no meio das palavras (ex.: "Vamozzz!"). Mantenha o estilo.

## Nomes (ficam em INGLÊS)
Pessoas (Hau, Lillie, Kukui, Hala, Gladion, Lusamine, Guzma, Plumeria, Burnet, Hapu, Olivia, Nanu, Acerola, Mallow, Lana, Kiawe, Sophocles, Ilima, Mina, Molayne, Kahili, Faba, Wicke, Dulse, Zossie, Phyco, Soliera, Mohn, Looker, Anabel...), Pokémon, golpes, habilidades, lugares (Alola, Melemele Island, Hau'oli City, Iki Town, Route 1, Ten Carat Hill, Aether Paradise, Ultra Megalopolis...), facções (Team Skull, Aether Foundation, Ultra Recon Squad, Team Rainbow Rocket), Ultra Beast(s), Ultra Wormhole, Ultra Space, Tapu Koko/Lele/Bulu/Fini, Poké Ball, Pokémon League, Battle Tree, Poké Pelago, Poké Finder, Island Scan, Berry/Berries, Mantine Surf, Roto Loto.

## Termos (use EXATAMENTE)
island challenge → desafio das ilhas · trial → provação · grand trial → grande provação · trial captain → capitão/capitã (da provação) · island kahuna / kahuna → kahuna (da ilha) · Totem Pokémon → Pokémon Totem · Z-Ring → Anel Z · Z-Power Ring → Anel do Poder Z · Z-Crystal → Cristal Z · Z-Move → Movimento Z · Z-Power → Poder Z · Ride Pokémon → Pokémon de Montaria · Rotom Dex → a Rotom Dex · Pokédex → a Pokédex · Pokémon Center → Centro Pokémon · Poké Mart → a Poké Mart · Elite Four → Elite dos 4 · Champion → Campeão/Campeã · Festival Plaza → Praça Festival · Trainer → Treinador(a) · Egg → Ovo · guardian deity → divindade guardiã · Hall of Fame → Hall da Fama · Pokémon Professor → Professor(a) Pokémon · Exp. Points → Pontos de Exp. · Legendary Pokémon → Pokémon Lendário
- Tipos em PT: Normal, Lutador, Voador, Venenoso, Terrestre, Pedra, Inseto, Fantasma, Aço, Fogo, Água, Planta, Elétrico, Psíquico, Gelo, Dragão, Sombrio, Fada. ("Water-type" → "do tipo Água").
- ITENS: use o nome PT do dicionário `/mnt/user-data/outputs/story/itens_dic.json` (ex.: Potion→Poção, Revive→Reviver, Rare Candy→Doce Raro). Consulte-o quando aparecer item.

## Verificação obrigatória antes de terminar
Rode um script Python que confira, comparando entrada x saída: (1) mesmo número de linhas; (2) linhas `### FILE` idênticas e na mesma posição; (3) por linha, o multiset de tokens `[VAR ...]`, `[WAIT n]`, `[~ n]` idêntico; (4) mesma quantidade de `\c` e `\r` por linha; (5) toda `{{...}}` bem formada com 3 partes e prefixo `1100:`/`1101:`; (6) nenhuma linha de fala ficou igual ao inglês (exceto `[~ N]`, interjeições e nomes). Corrija até passar tudo e reporte os números.

## TERMOS TRAVADOS (já usados no resto do jogo — obrigatório)
HP → HP (NUNCA "PS") · TM → MT · Bag → Mochila · Poké Beans → Poké Beans · Festival Coins → Moedas Festival · Grunt → Capanga · Hiker → Montanhista · Ace Trainer → Treinador Ás · Youngster → Jovem · Lass → Garota · Pokémon Breeder → Criador de Pokémon · Single Battle → Batalha Simples · Double Battle → Batalha Dupla · Multi Battle → Batalha Multi · Battle Royal → Battle Royal · Battle Legend → Lenda de Batalha · Captain (título) → Capitão/Capitã · Blinding One → o Ofuscante · Master Ball/Great Ball/Beast Ball e Cristais Z específicos (Firium Z etc.) → em inglês · Malasada → Malasada.
Naturezas (oficiais do jogo): Hardy Firme · Lonely Solitária · Brave Corajosa · Adamant Rígida · Naughty Danada · Bold Audaciosa · Docile Dócil · Relaxed Relaxada · Impish Traquina · Lax Relapsa · Timid Tímida · Hasty Apressada · Serious Séria · Jolly Alegre · Naive Ingênua · Modest Modesta · Mild Branda · Quiet Quieta · Bashful Recatada · Rash Impulsiva · Calm Calma · Gentle Gentil · Sassy Atrevida · Careful Cuidadosa · Quirky Peculiar.
Outros já usados: Trial Guide → Guia da Provação · Trainer Passport → Passaporte de Treinador · Gym/Gym Leader → Ginásio/Líder de Ginásio · Mega Stone → Mega Pedra · Surf Association → Associação de Surf · Rotom Dex no feminino ("a Rotom Dex") · dinheiro no formato $1.040 · Poké Balls específicas (Net Ball, Dive Ball...) em inglês.
