# Aviso legal

Este é um projeto **de fã**, sem fins lucrativos. *Pokémon*, *Pokémon Ultra Sun*,
os nomes de Pokémon, personagens, e todo o conteúdo original do jogo são marcas
registradas e propriedade da **Nintendo**, **Game Freak** e **The Pokémon
Company**. Este projeto **não é oficial** e não tem nenhum vínculo, patrocínio ou
aprovação dessas empresas.

## O que este repositório contém

Apenas **trabalho original dos colaboradores** e ferramentas:

- o **texto traduzido** para PT-BR (obra derivada dos colaboradores);
- **ferramentas** em Python escritas do zero;
- **documentação**.

## O que este repositório NÃO contém (e nunca deve conter)

Nada disto pode ser versionado ou publicado, porque é conteúdo protegido por
direitos autorais da Nintendo/Game Freak:

- a **ROM** do jogo (`.3ds`, `.cci`, `.cia`) — inteira ou em parte;
- os **arquivos originais** do jogo (`.garc`, `code.bin`, RomFS, ExeFS…);
- o **texto original em inglês** extraído do jogo (`extraido/`).

Por isso o `.gitignore` bloqueia esses arquivos. **Não os force para dentro do
repositório.**

## Como usar de forma responsável

- Use **somente** um dump do **seu próprio** cartucho/instalação que você comprou.
- Distribua **o patch** (a tradução), **nunca a ROM**. Quem quiser jogar aplica
  o patch no próprio dump.
- Não venda nem monetize este projeto nem nada derivado dele.

## Isenção de responsabilidade

O software é fornecido "como está", sem garantias, nos termos da GPLv3 (veja
`LICENSE`). Os colaboradores não se responsabilizam por qualquer dano ao seu
console, save ou arquivos. Faça backup antes de aplicar qualquer patch.
