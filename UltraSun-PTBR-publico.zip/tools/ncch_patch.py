"""Substitui arquivos no RomFS de um NCCH (dentro de CCI .3ds ou CIA) SEM mover nada:
o arquivo novo precisa ser <= ao original. Recalcula a arvore IVFC (L2,L1,master) e o
hash do superbloco RomFS no cabecalho NCCH.
Uso: python ncch_patch.py verify <imagem> <ncch_offset>
     python ncch_patch.py patch  <imagem> <ncch_offset> a/0/3/2=arq1 a/0/4/2=arq2"""
import struct,sys,hashlib
MU=0x200
class Img:
    def __init__(s,path,ncch,mode='rb'):
        s.f=open(path,mode); f=s.f; s.ncch=ncch
        f.seek(ncch+0x100); assert f.read(4)==b'NCCH','sem NCCH nesse offset'
        f.seek(ncch+0x188); fl=f.read(8); assert fl[7]&0x04,'NCCH criptografado'
        f.seek(ncch+0x1B0); ro,rs,rh=struct.unpack('<III',f.read(12)); s.romfs=ncch+ro*MU; s.hashreg=rh*MU
        f.seek(s.romfs); h=f.read(0x60); assert h[:4]==b'IVFC'
        s.mh=struct.unpack_from('<I',h,8)[0]
        s.lv=[]
        for i in range(3):
            lo,sz,bs=struct.unpack_from('<QQI',h,0x0C+i*0x18); s.lv.append(dict(lo=lo,size=sz,bs=1<<bs))
        al=lambda x,a:(x+a-1)//a*a
        L1,L2,L3=s.lv
        L3['off']=s.romfs+al(0x60+s.mh,L3['bs'])
        L1['off']=s.romfs+al(L3['off']-s.romfs+L3['size'],L1['bs'])
        L2['off']=s.romfs+al(L1['off']-s.romfs+L1['size'],L2['bs'])
        f.seek(L3['off']); hd=struct.unpack('<10I',f.read(40))
        s.dmeta=L3['off']+hd[3]; s.fmeta=L3['off']+hd[7]; s.fdata=L3['off']+hd[9]
    def rd(s,o,n): s.f.seek(o); return s.f.read(n)
    def blockhash(s,lvl,i):
        L=s.lv[lvl]; n=min(L['bs'],L['size']-i*L['bs']); d=s.rd(L['off']+i*L['bs'],n)
        return hashlib.sha256(d+b'\0'*(L['bs']-n)).digest()
    def stored(s,lvl,i):  # hash of block i of level lvl as stored in parent
        if lvl==0: return s.rd(s.romfs+0x60+i*32,32)
        return s.rd(s.lv[lvl-1]['off']+i*32,32)
    def verify(s,idx):
        bad=0
        for lvl in (0,1,2):
            nb=(s.lv[lvl]['size']+s.lv[lvl]['bs']-1)//s.lv[lvl]['bs']
            for i in (idx if lvl==2 else range(nb if lvl<2 else 0)):
                if i>=nb: continue
                if s.blockhash(lvl,i)!=s.stored(lvl,i): bad+=1
        sb=hashlib.sha256(s.rd(s.romfs,s.hashreg)).digest()==s.rd(s.ncch+0x1E0,32)
        return bad,sb
    # --- navegacao ---
    def _dir(s,o):
        s.f.seek(s.dmeta+o); p,sib,cd,cf,nh,nl=struct.unpack('<6I',s.f.read(24)); return sib,cd,cf,s.f.read(nl).decode('utf-16-le')
    def _file(s,o):
        s.f.seek(s.fmeta+o); p,sib,do,ds,nh,nl=struct.unpack('<IIQQII',s.f.read(32)); return sib,do,ds,s.f.read(nl).decode('utf-16-le')
    def find(s,path):
        d=0; parts=path.split('/')
        for j,p in enumerate(parts):
            _,cd,cf,_=s._dir(d)
            if j==len(parts)-1:
                o=cf
                while o!=0xFFFFFFFF:
                    sib,do,ds,n=s._file(o)
                    if n==p: return o,do,ds
                    o=sib
                raise KeyError(path)
            o=cd
            while o!=0xFFFFFFFF:
                sib,_,_,n=s._dir(o)
                if n==p: d=o; break
                o=sib
            else: raise KeyError(path)
def main():
    mode,path,ncch=sys.argv[1],sys.argv[2],int(sys.argv[3],0)
    im=Img(path,ncch,'rb' if mode=='verify' else 'r+b')
    L3=im.lv[2]
    if mode=='verify':
        import random
        nb=(L3['size']+L3['bs']-1)//L3['bs']; idx=[0,1,nb-1]+random.sample(range(nb),40)
        o,do,ds=im.find('a/0/3/2'); idx+= [ (im.fdata-L3['off']+do)//L3['bs'] ]
        print('L1/L2/L3 tamanhos',[l['size'] for l in im.lv],'blocos',[l['bs'] for l in im.lv])
        print('a/0/3/2',do,ds,'| (L1+master completos, L3 amostrado) blocos ruins, superbloco ok:',im.verify(idx))
        return
    dirty=set()
    for spec in sys.argv[4:]:
        rp,src=spec.split('='); new=open(src,'rb').read()
        o,do,ds=im.find(rp); assert len(new)<=ds,(rp,'maior que o original',len(new),ds)
        a=im.fdata+do
        im.f.seek(a); im.f.write(new+b'\0'*(ds-len(new)))
        im.f.seek(im.fmeta+o+16); im.f.write(struct.pack('<Q',len(new)))
        s0=(a-L3['off'])//L3['bs']; s1=(a+ds-1-L3['off'])//L3['bs']
        dirty.update(range(s0,s1+1)); dirty.add((im.fmeta+o+16-L3['off'])//L3['bs'])
        print('gravado',rp,len(new),'(orig',ds,')')
    # L3 -> L2
    d2=set()
    for i in sorted(dirty):
        h=im.blockhash(2,i); im.f.seek(im.lv[1]['off']+i*32); im.f.write(h); d2.add(i*32//im.lv[1]['bs'])
    d1=set()
    for i in sorted(d2):
        h=im.blockhash(1,i); im.f.seek(im.lv[0]['off']+i*32); im.f.write(h); d1.add(i*32//im.lv[0]['bs'])
    for i in sorted(d1):
        h=im.blockhash(0,i); im.f.seek(im.romfs+0x60+i*32); im.f.write(h)
    im.f.flush()
    h=hashlib.sha256(im.rd(im.romfs,im.hashreg)).digest(); im.f.seek(im.ncch+0x1E0); im.f.write(h); im.f.flush()
    print('hashes: L2',len(dirty),'L1',len(d2),'master',len(d1),'| verificacao:',im.verify(sorted(dirty)))
if __name__=='__main__': main()
