# HISTORICO / REFERENCIA — script usado uma vez na traducao original.
# O build oficial e reproduzivel e o tools/build_patch.py. Os caminhos abaixo
# (/mnt/user-data/...) sao do ambiente de origem e nao valem neste repo.
# -*- coding: utf-8 -*-
"""Integra lotes traduzidos do storytext: separa por arquivo, verifica, padroniza termos,
re-quebra linhas largas, converte {{110x:COND|a|b}} -> [VAR 110x(COND,PPSS)]ab e grava story/pt/NNNN.txt"""
import os,re,sys,glob,json
sys.path.insert(0,'/mnt/user-data/outputs/usum'); import overflow
W='/mnt/user-data/outputs/story'
COND=re.compile(r'\{\{(110[01]):([0-9A-F]{4})\|([^|{}]*)\|([^|{}]*)\}\}')
HARD=re.compile(r'\[VAR (?!110[01])[^\]]*\]|\[~ \d+\]|\[WAIT \d+\]')
TERMS=[(r'\bPS\b','HP'),(r'Moedas do Festival','Moedas Festival'),(r'Moeda do Festival','Moeda Festival'),
       (r'Poké Grãos','Poké Beans'),(r'Poké Grão\b','Poké Bean'),(r'Batalhas? Individua(l|is)',lambda m:'Batalha Simples' if m.group(0).startswith('Batalha ') else 'Batalhas Simples'),
       (r'\bMultibatalhas\b','Batalhas Multi'),(r'\bMultibatalha\b','Batalha Multi'),(r'Lenda da Batalha','Lenda de Batalha'),
       (r'\bRecrutas da Team','Capangas da Team'),(r'\bRecruta da Team','Capanga da Team'),(r'\bmiúdo\b','moleque')]
def split_chunk(path):
    files={};cur=None
    for l in open(path,encoding='utf-8').read().split('\n'):
        m=re.match(r'^### FILE (\d{4})$',l)
        if m: cur=m.group(1); files[cur]=[]; continue
        if cur is not None: files[cur].append(l)
    for k in files:
        while files[k] and files[k][-1]=='' : files[k].pop()
    return files
def resolved(l,which):  # which 0=primeira forma, 1=segunda
    return COND.sub(lambda m:m.group(3+which),l)
def vwidth(l): return max(max((overflow.width(v) for v in overflow.visual_lines(resolved(l,w))),default=0) for w in (0,1))
WORD=re.compile(r'(?:\{\{[^}]*\}\}|\[[^\]]*\]|[^\s\[{])+')
def wwidth(s): return max(overflow.width(resolved(s,0)),overflow.width(resolved(s,1)))
def wrap_to(chunk,Wd):
    ls=[];cur=''
    for w in WORD.findall(chunk):
        c=w if not cur else cur+' '+w
        if wwidth(c)>Wd and cur: ls.append(cur);cur=w
        else: cur=c
    if cur or not ls: ls.append(cur)
    return ls
def rewrap(l,bud,maxl):
    out=[]
    for p in re.split(r'(\\c|\\r)',l):
        if p in ('\\c','\\r'): out.append(p); continue
        ch=re.sub(r' +',' ',p.replace('\\n',' ')).strip(); Wd=bud
        while True:
            ls=wrap_to(ch,Wd)
            if len(ls)<=maxl or Wd>bud*1.25: break
            Wd+=0.4
        out.append('\\n'.join(ls))
    return ''.join(out)
def to_markers(l):
    def rep(m):
        a,b=m.group(3),m.group(4)
        assert '[' not in a+b and '\\' not in a+b, ('forma com codigo',l)
        return f'[VAR {m.group(1)}({m.group(2)},{len(b):02X}{len(a):02X})]{a}{b}'
    return COND.sub(rep,l)
def process(ci,report):
    en=split_chunk(f'{W}/chunks/c{ci:02d}_in.txt'); pt=split_chunk(f'{W}/chunks/c{ci:02d}_pt.txt')
    assert list(en)==list(pt),'blocos FILE diferentes'
    os.makedirs(f'{W}/pt',exist_ok=True); stats=dict(files=0,lines=0,fixed_terms=0,rewrap=0,err=[])
    for k in en:
        E,P=en[k],pt[k]
        if len(E)!=len(P): stats['err'].append((k,'linhas',len(P),len(E))); continue
        orig=[l for l in open(f'{W}/storytext_en/{k}.txt',encoding='utf-8-sig').read().replace('\r\n','\n').split('\n')]
        if orig and orig[-1]=='': orig.pop()
        bud=max(37.0,max((overflow.width(v) for l in orig for v in overflow.visual_lines(l)),default=0))
        maxl=max(2,max((len(s.split('\\n')) for l in orig for s in re.split(r'\\c|\\r',l)),default=1))
        out=[]
        for i,(e,p) in enumerate(zip(E,P)):
            q=p
            for pat,rep in TERMS: q=re.sub(pat,rep,q)
            if q!=p: stats['fixed_terms']+=1
            if sorted(HARD.findall(e))!=sorted(HARD.findall(q)): stats['err'].append((k,i,'tokens'))
            if e.count('\\c')!=q.count('\\c') or e.count('\\r')!=q.count('\\r'): stats['err'].append((k,i,'\\c/\\r'))
            if vwidth(q)>bud+0.5 or any(len(s.split('\\n'))>maxl for s in re.split(r'\\c|\\r',q)):
                q=rewrap(q,bud,maxl); stats['rewrap']+=1
            out.append(to_markers(q))
        open(f'{W}/pt/{k}.txt','w',encoding='utf-8').write(('\n'.join(out)+'\n') if out else '')
        stats['files']+=1; stats['lines']+=len(out)
    report[ci]=stats; return stats
if __name__=='__main__':
    rep={}
    for ci in map(int,sys.argv[1:]):
        s=process(ci,rep); print(f"c{ci:02d}: arquivos {s['files']} linhas {s['lines']} termos_corrigidos {s['fixed_terms']} requebradas {s['rewrap']} erros {len(s['err'])} {s['err'][:5]}")
