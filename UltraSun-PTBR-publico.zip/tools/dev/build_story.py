# HISTORICO / REFERENCIA — script usado uma vez na traducao original.
# O build oficial e reproduzivel e o tools/build_patch.py. Os caminhos abaixo
# (/mnt/user-data/...) sao do ambiente de origem e nao valem neste repo.
import os,sys,glob
sys.path.insert(0,'/mnt/user-data/outputs/usum')
from garc import GARC; from garc_pack import pack_garc
from textcodec import decode_textfile_full, encode_textfile
W='/mnt/user-data/outputs/story'
def rd(p):
    t=open(p,encoding='utf-8-sig',newline='').read().replace('\r\n','\n'); c=t.split('\n'); return c[:-1] if c and c[-1]=='' else c
o=GARC(open(f'{W}/orig_a_0_4_2.garc','rb').read()); n=len(o)
pt={int(os.path.basename(p)[:4]):rd(p) for p in glob.glob(f'{W}/pt/*.txt')}
blobs=[];used=0
for i in range(n):
    if i in pt:
        L,F=decode_textfile_full(o.get(i)); assert len(pt[i])==len(F),(i,len(pt[i]),len(F))
        blobs.append(encode_textfile(pt[i],F)); used+=1
    else: blobs.append(bytes(o.get(i)))
data=pack_garc(blobs); g=GARC(data); ok=0; same=0
for i in range(n):
    L,F=decode_textfile_full(g.get(i)); Lo,Fo=decode_textfile_full(o.get(i))
    if (L==pt[i] if i in pt else L==Lo) and F==Fo: ok+=1
    if i not in pt and g.get(i)==o.get(i): same+=1
open(f'{W}/a_0_4_2.garc','wb').write(data)
print(f"traduzidos {used}/{n} | integridade+flags {ok}/{n} | nao-traduzidos byte-identicos {same}/{n-used} | {len(data)} bytes")
