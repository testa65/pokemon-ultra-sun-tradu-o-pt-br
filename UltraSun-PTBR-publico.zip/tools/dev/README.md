# tools/dev — scripts de referência

Estes scripts foram usados **uma vez** durante a tradução original e ficam aqui
como referência. Eles **não** fazem parte do fluxo normal.

- `itens_gerar.py` / `itens_plural.py` — geraram o dicionário de itens
  (`traducao/itens_dic.json` e `itens_plural_exc.json`) a partir dos nomes em
  inglês. Rode só se quiser regenerar o dicionário do zero.
- `buscar.py` — busca uma palavra nos textos em inglês extraídos (precisa de
  `extraido/` populado; veja o README principal).
- `build_story.py` / `story_pipeline.py` — **históricos**. A montagem do GARC de
  história foi absorvida pelo `tools/build_patch.py`, que é o build oficial e
  reproduzível. Os caminhos `/mnt/user-data/...` dentro deles são do ambiente de
  origem e não valem neste repositório.

Para montar o patch, use sempre: `python tools/build_patch.py`
