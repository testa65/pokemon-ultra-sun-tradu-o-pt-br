# -*- coding: utf-8 -*-
import os
"""Gera 0041 (formas plurais) e 0042 (forma condicional) a partir de 0040 PT.

O jogo monta o nome assim:
    prefixo + [VAR 1101(00FE,PPSS)] + sufixo_singular(SS) + sufixo_plural(PP) + cauda
renderizando  prefixo+sufixo_singular+cauda  ou  prefixo+sufixo_plural+cauda.
Isso e um infixo, entao aguenta plural irregular do portugues (Poção/Poções).
"""
import re, json, os, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
EN = os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','extraido','gametext_en')
PT = os.path.join(AQUI, '..', 'pt')

PREP = {'de','do','da','dos','das','em','no','na','com','para','ao','à','a','o'}
# tokens que nunca flexionam: marcas, prefixos e codigos
NUNCA = {'Poké','Roto','Mega','Vs.','GB','TMV','N-Solarizador','N-Lunarizador','Gram'}
# substantivo/nome proprio usado como modificador nao flexiona:
# "Escamas Coração", "Fósseis Raiz", "Leites Moomoo"
MODIF = {'Moomoo','Unown','Rage','Azure','Mach','Acro','Eon','Magma','Aqua','Zygarde','Surge',
 'Devon','Enigma','Prisma','Plasma','Liberdade','Bálsamo','Amuleto','Macho','Surpresa','Coração',
 'Saudação','Convite','Obrigado','Pergunta','Ponte','Inseto','Draco','Raiz','Garra','Hélice',
 'Domo','Armadura','Crânio','Casca','Pluma','Mandíbula','Vela','Chantili','Fantasma','Prisão',
 'Festival','Usina','Looker','Navio','Concurso','Explorador'}

def eh_verbo(w):
    """Infinitivo usado como nome de item (Reviver, Chocar) nao flexiona."""
    b = w.lower()
    if any(c in b for c in 'áéíóúâêôãõç'): return False   # acento => nao e infinitivo
    return len(w) > 4 and b.endswith(('ar','er','ir'))

def invariavel(w):
    return (w in NUNCA or len(w) <= 2 or w.isdigit() or w.endswith('.')
            or re.fullmatch(r'[A-Z]', w) or re.fullmatch(r'(MT|MO)\d+', w)
            or eh_verbo(w))

def plural_palavra(p):
    if not p or not p[0].isalpha(): return p            # numeros, codigos
    b = p.lower()
    if b.endswith('ão'):  return p[:-2] + 'ões'
    if b.endswith('m'):   return p[:-1] + 'ns'
    if b.endswith('aiz'): return p[:-3] + 'aízes'
    if b.endswith(('r','z')): return p + 'es'
    if b.endswith('s'):   return p                       # ja plural / invariavel
    if b.endswith('x'):   return p                       # invariavel
    if b.endswith('al'):  return p[:-2] + 'ais'
    if b.endswith('el'):
        ja = any(c in b[:-2] for c in 'áéíóúâêô')
        return p[:-2] + ('eis' if ja else 'éis')
    if b.endswith('il'):
        # paroxitona (acentuada) -> eis  (Fóssil/Fósseis);  oxitona -> is (fuzil/fuzis)
        acent = any(c in b[:-2] for c in 'áéíóúâêôãõ')
        return p[:-2] + ('eis' if acent else 'is')
    if b.endswith('ol'):  return p[:-2] + 'óis'
    if b.endswith('ul'):  return p[:-2] + 'uis'
    return p + 's'

def pluralizar(nome, exc, en_sing=None, en_plur=None):
    if nome in exc: return exc[nome]
    if nome.strip() in ('', '?????', '???', '-'): return nome
    # nome que eu mantive em ingles -> usar o plural ingles original
    if en_sing is not None and nome == en_sing: return en_plur
    # "Fruta <Nome>" / "Placa <Nome>": so a cabeca flexiona, o resto e nome proprio
    for cab in ('Fruta ', 'Néctar ', 'Apricorn '):
        if nome.startswith(cab):
            return plural_palavra(cab.strip()) + ' ' + nome[len(cab):]
    palavras = nome.split(' ')
    saida = []
    parou = False          # depois de preposicao, nao flexiona mais
    for w in palavras:
        if w.lower() in PREP: parou = True; saida.append(w); continue
        cabeca = (len(saida) == 0)
        fixo = parou or invariavel(w) or (not cabeca and w in MODIF)
        saida.append(w if fixo else plural_palavra(w))
    return ' '.join(saida)

def montar_condicional(s, p):
    """Calcula prefixo/sufixos/cauda e devolve a string com o marcador."""
    if s == p:
        return s + '[VAR 1101(00FE,0000)]'
    # maior prefixo comum
    i = 0
    while i < min(len(s), len(p)) and s[i] == p[i]: i += 1
    pre = s[:i]; rs, rp = s[i:], p[i:]
    # maior cauda comum do que sobrou
    j = 0
    while j < min(len(rs), len(rp)) and rs[len(rs)-1-j] == rp[len(rp)-1-j]: j += 1
    cauda = rs[len(rs)-j:] if j else ''
    sufs = rs[:len(rs)-j] if j else rs
    sufp = rp[:len(rp)-j] if j else rp
    return f'{pre}[VAR 1101(00FE,{len(sufp):02X}{len(sufs):02X})]{sufs}{sufp}{cauda}'

def ler(p):
    c = open(p, encoding='utf-8').read().split('\n')
    return c[:-1] if c and c[-1] == '' else c

def main():
    exc = json.load(open(os.path.join(AQUI, 'plural_exc.json'), encoding='utf-8')) \
          if os.path.isfile(os.path.join(AQUI, 'plural_exc.json')) else {}
    sing = ler(os.path.join(PT, '0040.txt'))
    en42 = ler(os.path.join(EN, '0042.txt'))
    en40 = ler(os.path.join(EN, '0040_ItemNames.txt'))
    en41 = ler(os.path.join(EN, '0041.txt'))
    plur, cond = [], []
    for i, s in enumerate(sing):
        p = pluralizar(s, exc, en40[i], en41[i])
        plur.append(p)
        # so poe marcador onde o ingles tinha
        cond.append(montar_condicional(s, p) if '[VAR 1101' in en42[i] else s)
    if '--gerar' in sys.argv:
        open(os.path.join(PT, '0041.txt'), 'w', encoding='utf-8').write(''.join(x+'\n' for x in plur))
        open(os.path.join(PT, '0042.txt'), 'w', encoding='utf-8').write(''.join(x+'\n' for x in cond))
        print(f"0041.txt e 0042.txt gerados ({len(plur)} linhas cada)")
    return sing, plur, cond

if __name__ == '__main__':
    s, p, c = main()
    if '--amostra' in sys.argv:
        for i in (0,1,17,23,28,50,78,111,226,428,450,651,795,797,949):
            print(f"{i:>4} | {s[i]:<24} | {p[i]:<26} | {c[i]}")
