#!/usr/bin/env python3
"""Busca palavras-chave nos textos extraidos e diz em qual subarquivo/linha estao.

Uso:
    python buscar.py Kukui
    python buscar.py "moving to Alola"
    python buscar.py Kukui --pasta storytext_en
    python buscar.py mom --contexto 2

Por padrao busca nas duas pastas (gametext_en e storytext_en).
"""
import sys, os, glob, argparse

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'extraido')

def buscar(termo, pastas, contexto=0, limite=60):
    termo_l = termo.lower()
    achados = 0
    for pasta in pastas:
        d = os.path.join(BASE, pasta)
        if not os.path.isdir(d):
            print(f"(pasta nao encontrada: {d})"); continue
        for p in sorted(glob.glob(os.path.join(d, '*.txt'))):
            linhas = open(p, encoding='utf-8').read().split('\n')
            nome = os.path.basename(p)
            for i, l in enumerate(linhas):
                if termo_l in l.lower():
                    achados += 1
                    print(f"\n[{pasta}/{nome}] linha {i}")
                    ini = max(0, i - contexto); fim = min(len(linhas), i + contexto + 1)
                    for j in range(ini, fim):
                        marca = '>>' if j == i else '  '
                        print(f"  {marca} {j:>4}: {linhas[j][:160]}")
                    if achados >= limite:
                        print(f"\n(parou em {limite} resultados — refine a busca)"); return
    print(f"\ntotal: {achados} ocorrencia(s)")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('termo')
    ap.add_argument('--pasta', default=None, help='gametext_en ou storytext_en')
    ap.add_argument('--contexto', type=int, default=0)
    ap.add_argument('--limite', type=int, default=60)
    a = ap.parse_args()
    pastas = [a.pasta] if a.pasta else ['gametext_en', 'storytext_en']
    buscar(a.termo, pastas, a.contexto, a.limite)
