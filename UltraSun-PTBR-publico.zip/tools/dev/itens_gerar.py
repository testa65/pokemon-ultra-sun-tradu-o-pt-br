# -*- coding: utf-8 -*-
import os
"""Gera traducao dos nomes de item aplicando regras + dicionario manual."""
import re, os, sys, json

D = os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','extraido','gametext_en')
AQUI = os.path.dirname(os.path.abspath(__file__))

def carregar_dic():
    p = os.path.join(AQUI, 'dic.json')
    return json.load(open(p, encoding='utf-8')) if os.path.isfile(p) else {}


MEMORIA = {'Fighting':'Memória de Luta','Flying':'Memória Voadora','Poison':'Memória de Veneno',
 'Ground':'Memória de Terra','Rock':'Memória de Pedra','Bug':'Memória de Inseto',
 'Ghost':'Memória Fantasma','Steel':'Memória de Aço','Fire':'Memória de Fogo',
 'Water':'Memória de Água','Grass':'Memória de Planta','Electric':'Memória Elétrica',
 'Psychic':'Memória Psíquica','Ice':'Memória de Gelo','Dragon':'Memória de Dragão',
 'Dark':'Memória Sombria','Fairy':'Memória de Fada'}
CORESF = {'Red':'Vermelha','Blue':'Azul','Yellow':'Amarela','Green':'Verde','Pink':'Rosa',
 'White':'Branca','Black':'Preta','Orange':'Laranja','Purple':'Roxa'}
XSTAT = {'Attack':'Ataque','Defense':'Defesa','Speed':'Velocidade',
         'Accuracy':'Precisão','Sp. Atk':'Atq. Esp.','Sp. Def':'Def. Esp.'}
CORES = {'Red':'Vermelho','Blue':'Azul','Yellow':'Amarelo','Green':'Verde',
         'Pink':'Rosa','White':'Branco','Black':'Preto','Orange':'Laranja','Purple':'Roxo'}
GEMAS = {'Fire':'Gema de Fogo','Water':'Gema de Água','Electric':'Gema Elétrica',
 'Grass':'Gema de Planta','Ice':'Gema de Gelo','Fighting':'Gema de Luta',
 'Poison':'Gema de Veneno','Ground':'Gema de Terra','Flying':'Gema Voadora',
 'Psychic':'Gema Psíquica','Bug':'Gema de Inseto','Rock':'Gema de Pedra',
 'Ghost':'Gema Fantasma','Dragon':'Gema de Dragão','Dark':'Gema Sombria',
 'Steel':'Gema de Aço','Normal':'Gema Normal','Fairy':'Gema de Fada'}

# ficam em ingles: nomes de produto/marca e nomes proprios
MANTER = re.compile(
    r'^(Master|Ultra|Great|Poké|Safari|Net|Dive|Nest|Repeat|Timer|Luxury|Premier|'
    r'Dusk|Heal|Quick|Cherish|Level|Lure|Moon|Friend|Love|Fast|Heavy|Beast|Dream|Sport|Park) Ball$'
)

def traduzir(nome, dic):
    if nome in dic: return dic[nome]
    if nome.strip() in ('', '?????', '???', '-'): return nome
    if MANTER.match(nome): return nome
    m = re.fullmatch(r'TM(\d+)', nome)
    if m: return f'MT{m.group(1)}'
    m = re.fullmatch(r'HM(\d+)', nome)
    if m: return f'MO{m.group(1)}'
    if nome.endswith(' Berry'): return 'Fruta ' + nome[:-6]
    m = re.fullmatch(r'Data Card (\d+)', nome)
    if m: return f'Cartão de Dados {m.group(1)}'
    m = re.fullmatch(r'(\w+) Apricorn', nome)
    if m and m.group(1) in CORES: return 'Apricorn ' + CORES[m.group(1)]
    m = re.fullmatch(r'(.+) Gem', nome)
    if m and m.group(1) in GEMAS: return GEMAS[m.group(1)]
    # Mega Stones: nome proprio derivado da especie -> fica em ingles
    if re.fullmatch(r'[A-Z][A-Za-z]+ite( [XY])?', nome): return nome
    # itens X com numero de estagio: X Attack 2 -> X Ataque 2
    m = re.fullmatch(r'X (Attack|Defense|Speed|Accuracy|Sp\. Atk|Sp\. Def) (\d)', nome)
    if m: return f'X {XSTAT[m.group(1)]} {m.group(2)}'
    m = re.fullmatch(r'Dire Hit (\d)', nome)
    if m: return f'Golpe Certeiro {m.group(1)}'
    m = re.fullmatch(r'(.+) Memory', nome)
    if m and m.group(1) in MEMORIA: return MEMORIA[m.group(1)]
    m = re.fullmatch(r'(\w+) Nectar', nome)
    if m and m.group(1) in CORES: return 'Néctar ' + CORES[m.group(1)]
    m = re.fullmatch(r'(\w+) Petal', nome)
    if m and m.group(1) in CORES: return 'Pétala ' + CORESF[m.group(1)]
    m = re.fullmatch(r'Key to Room (\d)', nome)
    if m: return f'Chave do Quarto {m.group(1)}'
    if re.search(r'ium Z$', nome): return nome          # cristais Z: nome proprio
    return None                                          # ainda nao coberto

def main():
    L = open(os.path.join(D, '0040_ItemNames.txt'), encoding='utf-8').read().split('\n')[:-1]
    dic = carregar_dic()
    faltando = []
    saida = []
    for i, n in enumerate(L):
        t = traduzir(n, dic)
        if t is None:
            faltando.append((i, n)); saida.append(n)
        else:
            saida.append(t)
    if '--gerar' in sys.argv:
        open(os.path.join(AQUI, '..', 'pt', '0040.txt'), 'w', encoding='utf-8').write(
            ''.join(x + '\n' for x in saida))
        print(f"0040.txt gerado ({len(saida)} linhas) | ainda sem traducao: {len(faltando)}")
    else:
        print(f"cobertos: {len(L)-len(faltando)} / {len(L)}   |   faltando: {len(faltando)}")
        ini = int(sys.argv[sys.argv.index('--de')+1]) if '--de' in sys.argv else 0
        qtd = int(sys.argv[sys.argv.index('--qtd')+1]) if '--qtd' in sys.argv else 120
        for i, n in faltando[ini:ini+qtd]:
            print(f"{i}\t{n}")

main()
