import struct
def pack_garc(files, pad_to=4):
    n=len(files); fato=0xC+n*4; fatb=0xC+n*16
    data=bytearray(); ents=[]; lu=0; lp=0; od=0
    for f in files:
        r=len(f)%pad_to; pad=(pad_to-r) if r else 0
        ents.append((od,od+len(f)+pad,len(f)))
        data+=f; data+=b'\xFF'*pad; od+=len(f)+pad
        if len(f)>lu: lu=len(f); lp=len(f)+pad
    hl=0x24+fato+fatb+0xC; tl=hl+len(data)
    o=bytearray()
    o+=struct.pack('<4sIHHIII',b'CRAG',0x24,0xFEFF,0x0600,4,hl,tl)
    o+=struct.pack('<III',lp,lu,pad_to)
    o+=struct.pack('<4sIHH',b'OTAF',fato,n,0xFFFF)
    op=0
    for i in range(n): o+=struct.pack('<I',op); op+=16
    o+=struct.pack('<4sII',b'BTAF',fatb,n)
    for s,e,l in ents: o+=struct.pack('<I',1)+struct.pack('<III',s,e,l)
    o+=struct.pack('<4sII',b'BMIF',0xC,len(data)); o+=data
    assert len(o)==tl; return bytes(o)
