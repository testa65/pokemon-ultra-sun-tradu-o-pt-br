#!/usr/bin/env python3
"""Extrai os dois arquivos de texto do jogo do SEU dump para build/orig/.

Aceita um dump DESCRIPTOGRAFADO: .3ds/.cci (NCSD), .cia, ou um NCCH solto.
Coloca em build/orig/:  a_0_3_2.garc (interface) e a_0_4_2.garc (historia).

Opcional: --ingles tambem grava o texto ORIGINAL em ingles decodificado em
extraido/{gametext_en,storytext_en}/*.txt, util como referencia pra traduzir.

Uso:
    python extrair_originais.py "caminho/do/seu/Pokemon Ultra Sun.3ds"
    python extrair_originais.py "seu_dump.cia" --ingles
"""
import sys, os, struct, argparse
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
RAIZ = os.path.join(AQUI, '..')
from ncch_patch import Img
MU = 0x200

def achar_ncch(path):
    """Devolve o offset do NCCH do conteudo 0, seja .3ds/.cci, .cia ou NCCH solto."""
    with open(path, 'rb') as f:
        f.seek(0x100); mag = f.read(4)
        if mag == b'NCSD':                       # .3ds / .cci
            f.seek(0x120); off = struct.unpack('<I', f.read(4))[0]; return off * MU
        if mag == b'NCCH':                        # NCCH solto
            return 0
        f.seek(0); head = f.read(0x20)
        hs = struct.unpack_from('<I', head, 0)[0]
        if hs == 0x2020:                          # .cia
            cs, ts, tm = struct.unpack_from('<III', head, 0x08)
            al = lambda x: (x + 63) // 64 * 64
            return al(hs) + al(cs) + al(ts) + al(tm)
    raise SystemExit('formato nao reconhecido (esperado .3ds/.cci descriptografado, .cia ou NCCH)')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('dump', help='seu dump DESCRIPTOGRAFADO (.3ds/.cci/.cia)')
    ap.add_argument('--ingles', action='store_true', help='tambem grava o texto EN em extraido/ (referencia)')
    a = ap.parse_args()
    ncch = achar_ncch(a.dump)
    im = Img(a.dump, ncch, 'rb')
    destino = os.path.join(RAIZ, 'build', 'orig'); os.makedirs(destino, exist_ok=True)
    for rp, nome in (('a/0/3/2', 'a_0_3_2.garc'), ('a/0/4/2', 'a_0_4_2.garc')):
        o, do, ds = im.find(rp)
        dados = im.rd(im.fdata + do, ds)
        open(os.path.join(destino, nome), 'wb').write(dados)
        print(f'  {rp} -> build/orig/{nome}  ({ds} bytes)')
    if a.ingles:
        from garc import GARC
        from textcodec import decode_textfile
        for nome, pasta in (('a_0_3_2.garc', 'gametext_en'), ('a_0_4_2.garc', 'storytext_en')):
            g = GARC(open(os.path.join(destino, nome), 'rb').read())
            d = os.path.join(RAIZ, 'extraido', pasta); os.makedirs(d, exist_ok=True)
            n = len(g)
            for i in range(n):
                linhas = decode_textfile(g.get(i))
                open(os.path.join(d, f'{i:04d}.txt'), 'w', encoding='utf-8', newline='\n').write('\n'.join(linhas) + '\n')
            print(f'  ingles -> extraido/{pasta}/  ({n} arquivos)')
    print('\nPronto. Agora rode: python tools/build_patch.py')

if __name__ == '__main__':
    main()
