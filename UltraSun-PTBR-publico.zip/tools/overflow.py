"""Verificador de estouro de caixa de texto (USUM PT-BR).

Regra: o texto ingles original foi publicado no jogo, logo ele CABE.
Cada subarquivo corresponde a uma tela, entao o orcamento daquela tela e a
linha visual mais larga que o ingles usa ali. Qualquer linha traduzida que
passe disso e forte candidata a estourar a caixa.

A fonte do 3DS e proporcional, entao a largura e estimada por tabela.
Codigos de controle nao ocupam espaco; [VAR ...] vira largura nominal, pois
em execucao vira um nome (Pokemon/treinador/item).
"""
import re, os, glob

NARROW = "iíìîïjlItf.,;:'!|[]()1 "
WIDE   = "mwMW@%"
CAPS   = "ABCDEFGHIJKLMNOPQRSTUVXYZÁÀÂÃÉÊÍÓÔÕÚÇ"
# Largura nominal de um [VAR] depende do que ele carrega em execucao:
# 02xx = campos numericos (dia, mes, ano, nivel, dinheiro) -> curtos
# 01xx = nomes (Pokemon, treinador, item, local)           -> longos
# BDxx/BExx/FFxx = formatacao (cor, pausa, icone)          -> nao renderizam
def var_width(code):
    c = code.upper()
    if c.startswith(('BD','BE','FF')): return 0.0
    if c.startswith('02'):             return 2.5
    if c.startswith('01'):             return 9.0
    if c.startswith('11'):             return 1.0   # plural condicional
    if c.startswith('13'):             return 0.0   # marcador de estilo
    return 6.0

def char_w(c):
    if c == ' ':    return 0.30
    if c in NARROW: return 0.38
    if c in WIDE:   return 1.00
    if c in CAPS:   return 0.75
    return 0.58

def visual_lines(s):
    s = s.replace('\\c', '\n').replace('\\r', '\n')
    out = []
    for p in s.split('\\n'):
        out.extend(p.split('\n'))
    return out

CONDIC = re.compile(r'\[VAR 1101\(00FE,([0-9A-F]{4})\)\](.*)$')

def _resolver_condicional(s):
    """O marcador 1101 guarda sufixo singular E plural na mesma string, mas o
    jogo desenha so um dos dois. Devolve a forma mais larga das duas."""
    m = CONDIC.search(s)
    if not m: return s
    pre = s[:m.start()]
    PP = int(m.group(1)[:2], 16); SS = int(m.group(1)[2:], 16)
    resto = m.group(2)
    sing = pre + resto[:SS] + resto[SS+PP:]
    plur = pre + resto[SS:SS+PP] + resto[SS+PP:]
    return sing if len(sing) >= len(plur) else plur

def width(s):
    s = _resolver_condicional(s)
    s = re.sub(r'\[(WAIT \d+|~ \d+)\]', '', s)
    extra = sum(var_width(m) for m in re.findall(r'\[VAR ([0-9A-Fa-f]{4})', s))
    s = re.sub(r'\[VAR [^\]]*\]', '', s).replace('\\\\', '\\')
    return sum(char_w(c) for c in s) + extra

def load(p):
    c = open(p, encoding='utf-8').read().split('\n')
    return c[:-1] if c and c[-1] == '' else c

def report(en_dir, pt_dir, growth=1.30):
    en_map = {int(os.path.basename(p).split('_')[0].split('.')[0]): p
              for p in glob.glob(os.path.join(en_dir, '*.txt'))}
    over_all = []; grow_all = []
    rows = []
    for p in sorted(glob.glob(os.path.join(pt_dir, '*.txt'))):
        try: idx = int(os.path.basename(p).split('_')[0].split('.')[0])
        except ValueError: continue
        pt = load(p)
        if idx not in en_map:
            rows.append((idx, None, None, 'sem EN')); continue
        en = load(en_map[idx])
        bud = max((width(v) for l in en for v in visual_lines(l)), default=0)
        over = [(i, round(width(v),1), v) for i,l in enumerate(pt)
                for v in visual_lines(l) if width(v) > bud + 0.5]
        grow = []
        for i,l in enumerate(pt):
            if i < len(en):
                we = max((width(v) for v in visual_lines(en[i])), default=0)
                wp = max((width(v) for v in visual_lines(l)), default=0)
                if we > 4 and wp > we*growth: grow.append((i, round(we,1), round(wp,1)))
        mx = max((width(v) for l in pt for v in visual_lines(l)), default=0)
        rows.append((idx, round(bud,1), round(mx,1),
                     ('ESTOURA %d' % len(over)) if over else ('cresceu %d' % len(grow)) if grow else 'ok'))
        over_all += [(idx,)+o for o in over]; grow_all += [(idx,)+g for g in grow]
    return rows, over_all, grow_all
