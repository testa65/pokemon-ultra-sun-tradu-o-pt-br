#!/usr/bin/env python3
"""Monta o patch LayeredFS PT-BR do Pokemon Ultra Sun a partir das SUAS traducoes
e dos arquivos ORIGINAIS do jogo (que voce extrai do seu proprio dump).

Entradas:
    build/orig/a_0_3_2.garc   <- extraia do SEU dump (romfs a/0/3/2) — texto de interface
    build/orig/a_0_4_2.garc   <- extraia do SEU dump (romfs a/0/4/2) — texto de historia
    traducao/gametext/*.txt   <- suas traducoes (interface)
    traducao/storytext/*.txt  <- suas traducoes (historia)

Para cada subarquivo:
  - com traducao: reaproveita as FLAGS por linha do original (essenciais pro jogo
    renderizar certo) e re-codifica com o seu texto;
  - sem traducao: copia o subarquivo original byte a byte.
Assim o build e reproduzivel — os mesmos textos geram exatamente o mesmo GARC.

Antes de montar, verifica contagem de linhas e estouro de caixa de texto.

Uso:
    python build_patch.py              # monta tudo
    python build_patch.py --so-checar  # so verifica, nao monta
"""
import sys, os, glob, argparse

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
RAIZ = os.path.join(AQUI, '..')

from textcodec import decode_textfile_full, encode_textfile
from garc import GARC
from garc_pack import pack_garc
import overflow

TITLE_ID = '00040000001B5000'
JOBS = [
    # (garc_original, pasta_traducao, caminho_no_romfs)
    ('a_0_3_2.garc', 'gametext',  ('a', '0', '3', '2')),
    ('a_0_4_2.garc', 'storytext', ('a', '0', '4', '2')),
]

def ler(p):
    # utf-8-sig + normaliza CRLF: aceita arquivo salvo no Windows sem enfiar \r no jogo.
    txt = open(p, encoding='utf-8-sig', newline='').read().replace('\r\n', '\n')
    c = txt.split('\n')
    return c[:-1] if c and c[-1] == '' else c

def indexar(pasta):
    saida = {}
    if not os.path.isdir(pasta): return saida
    for p in glob.glob(os.path.join(pasta, '*.txt')):
        try: i = int(os.path.basename(p).split('_')[0].split('.')[0])
        except ValueError: continue
        saida[i] = p
    return saida

def carregar_aceitos():
    """traducao/aceito.txt: <pasta> <subarquivo>  # motivo — suprime avisos de estouro ja analisados."""
    p = os.path.join(RAIZ, 'traducao', 'aceito.txt')
    ac = set()
    if os.path.isfile(p):
        for l in open(p, encoding='utf-8'):
            l = l.split('#')[0].strip()
            if not l: continue
            partes = l.split()
            if len(partes) >= 2:
                try: ac.add((partes[0], int(partes[1])))
                except ValueError: pass
    return ac

def main(so_checar=False):
    total_traduzido = 0
    problemas = 0
    aceitos = carregar_aceitos()
    if aceitos: print(f"(lista de excecoes de estouro: {len(aceitos)} entrada(s))")
    for garc_orig, pasta_pt, romfs in JOBS:
        orig_path = os.path.join(RAIZ, 'build', 'orig', garc_orig)
        dpt = os.path.join(RAIZ, 'traducao', pasta_pt)
        if not os.path.isfile(orig_path):
            print(f"[!] {garc_orig}: nao achei o original em build/orig/{garc_orig}")
            print(f"    Extraia romfs {'/'.join(romfs)} do SEU dump e salve ai. Veja o README.")
            problemas += 1; continue
        orig = GARC(open(orig_path, 'rb').read())
        n = len(orig)
        pt = indexar(dpt)
        print(f"\n=== {garc_orig} -> {'/'.join(romfs)} ===")
        print(f"    subarquivos: {n} | traduzidos: {len(pt)}")

        dec = [decode_textfile_full(orig.get(i)) for i in range(n)]  # (linhas_en, flags) por subarquivo

        # 1) contagem de linhas (cada linha do original = uma linha na traducao)
        erros = []
        for i, p in sorted(pt.items()):
            if i >= n:
                erros.append(f"subarquivo {i} nao existe no original (max {n-1})"); continue
            a, b = len(ler(p)), len(dec[i][1])
            if a != b:
                erros.append(f"subarquivo {i}: {a} linhas traduzidas != {b} originais")
        if erros:
            print("    [ERRO] contagem de linhas nao bate:")
            for e in erros[:20]: print("      -", e)
            print("    Corrija antes de montar.")
            problemas += len(erros); continue

        # 2) estouro de caixa: orcamento = linha visual mais larga que o ingles usa ali
        estouros = []
        for i, p in sorted(pt.items()):
            if (pasta_pt, i) in aceitos: continue
            en_lines = dec[i][0]
            bud = max((overflow.width(v) for l in en_lines for v in overflow.visual_lines(l)), default=0)
            for li, l in enumerate(ler(p)):
                for v in overflow.visual_lines(l):
                    if overflow.width(v) > bud + 0.5:
                        estouros.append((i, li, round(overflow.width(v), 1), v))
        if estouros:
            print(f"    [AVISO] {len(estouros)} linha(s) podem estourar a caixa:")
            for o in estouros[:12]:
                print(f"      sub {o[0]} linha {o[1]}  larg={o[2]} | {o[3][:60]}")
            if len(estouros) > 12: print(f"      ... e mais {len(estouros) - 12}")
        else:
            print("    estouro de caixa: nenhum")

        total_traduzido += len(pt)
        if so_checar: continue

        # 3) montar GARC: traduzidos com as flags originais; nao-traduzidos byte a byte
        blobs = []
        for i in range(n):
            if i in pt:
                blobs.append(encode_textfile(ler(pt[i]), dec[i][1]))
            else:
                blobs.append(bytes(orig.get(i)))
        dados = pack_garc(blobs)
        destino = os.path.join(RAIZ, 'LayeredFS', TITLE_ID, 'romfs', *romfs)
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        open(destino, 'wb').write(dados)
        g2 = GARC(dados)
        iguais = sum(1 for i in range(n) if i not in pt and bytes(g2.get(i)) == bytes(orig.get(i)))
        print(f"    montado: {len(dados)} bytes | nao-traduzidos byte-identicos ao original: {iguais}/{n - len(pt)}")

    print(f"\nsubarquivos traduzidos no total: {total_traduzido}")
    if problemas:
        print(f"problemas encontrados: {problemas}")
    elif not so_checar:
        print(f"\nPatch pronto em: LayeredFS/{TITLE_ID}/")
        print("Copie a pasta 'romfs' para (Azahar):")
        print("  %APPDATA%\\Azahar\\load\\mods\\00040000001B5000")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--so-checar', action='store_true')
    main(ap.parse_args().so_checar)
