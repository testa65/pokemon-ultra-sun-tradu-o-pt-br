"""CCI (.3ds decriptado) -> CIA decriptado, reaproveitando cert/ticket/TMD/meta do CIA original.
Retomavel: cada execucao copia ate <budget> segundos; estado SHA-256 salvo em arquivo (OpenSSL ctx).
Uso: python cci2cia.py <cci> <cia_original> <cia_saida> [budget_s]"""
import sys,os,json,struct,hashlib,ctypes,ctypes.util,time
cci,ocia,out=sys.argv[1:4]; budget=float(sys.argv[4]) if len(sys.argv)>4 else 110
C=ctypes.CDLL(ctypes.util.find_library('crypto')); ST=out+'.state.json'
al=lambda x:(x+63)//64*64
o=open(ocia,'rb'); h=o.read(0x2020)
hs,_,_,cs,ts,tm,ms,cz=struct.unpack_from('<IHHIIIIQ',h,0)
co=al(hs); to=co+al(cs); tmo=to+al(ts); cto=tmo+al(tm)
th=tmo+4+0x100+0x3C
o.seek(th); hdr=bytearray(o.read(0xC4)); n=struct.unpack('>H',hdr[0x9E:0xA0])[0]
cir=bytearray(o.read(0x900)); crs=bytearray(o.read(0x30*n))
g=open(cci,'rb'); g.seek(0x120); pt=struct.unpack('<16I',g.read(64))
parts=[(pt[2*i]*0x200,pt[2*i+1]*0x200) for i in range(n)]
offs=[];p=cto
for i in range(n):
    size=struct.unpack_from('>Q',crs,i*0x30+8)[0]; assert size==parts[i][1],(i,size,parts[i]); offs.append(p); p+=al(size)
meta_off=p; total=meta_off+ms
st=json.load(open(ST)) if os.path.exists(ST) else {'i':0,'pos':0,'ctx':None,'hashes':[]}
if not os.path.exists(out): open(out,'wb').close()
w=open(out,'r+b'); t0=time.time()
while st['i']<n and time.time()-t0<budget:
    i=st['i']; src,size=parts[i]
    ctx=ctypes.create_string_buffer(bytes.fromhex(st['ctx']),256) if st['ctx'] else ctypes.create_string_buffer(256)
    if not st['ctx']: C.SHA256_Init(ctx)
    pos=st['pos']; g.seek(src+pos); w.seek(offs[i]+pos)
    while pos<size and time.time()-t0<budget:
        b=g.read(min(32<<20,size-pos)); C.SHA256_Update(ctx,b,len(b)); w.write(b); pos+=len(b)
    w.flush(); os.fsync(w.fileno())
    if pos==size:
        dg=ctypes.create_string_buffer(32); C.SHA256_Final(dg,ctx); st['hashes'].append(dg.raw.hex())
        pad=al(size)-size; w.seek(offs[i]+size); w.write(b'\0'*pad); st.update(i=i+1,pos=0,ctx=None)
    else: st.update(pos=pos,ctx=ctx.raw.hex())
    json.dump(st,open(ST,'w'))
if st['i']==n:
    for i in range(n):
        b=i*0x30; ctype=struct.unpack_from('>H',crs,b+6)[0]&~1
        struct.pack_into('>H',crs,b+6,ctype); crs[b+16:b+48]=bytes.fromhex(st['hashes'][i])
    cnt=struct.unpack_from('>H',cir,2)[0]; cir[4:36]=hashlib.sha256(bytes(crs[:cnt*0x30])).digest()
    hdr[0xA4:0xC4]=hashlib.sha256(bytes(cir)).digest()
    o.seek(0); pre=bytearray(o.read(cto))
    pre[th-0:th+0xC4]=hdr; pre[th+0xC4:th+0xC4+0x900]=cir; pre[th+0xC4+0x900:th+0xC4+0x900+0x30*n]=crs
    w.seek(0); w.write(pre)
    o.seek(meta_off); w.seek(meta_off); w.write(o.read(ms)); w.truncate(total); w.flush()
    print('CIA PRONTO',total,'bytes; hashes',st['hashes'])
else:
    print('parcial: conteudo',st['i'],'pos',st['pos'],'%.1f%%'%(100*(parts[0][1]*0+ (sum(parts[j][1] for j in range(st['i']))+st['pos']))/sum(s for _,s in parts)))
