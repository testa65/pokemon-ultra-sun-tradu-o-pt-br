import sys,hashlib; sys.path.insert(0,'tools'); from ncch_patch import Img
SRC="../3ds/Pokemon Ultra Sun-decrypted.cci"; DST="build/Pokemon Ultra Sun PT-BR.3ds"
o=Img(SRC,0x4000); L1,L2,L3=o.lv; B=4096
R=[(0x4000,L3['off']+2*B),(L1['off'],L1['size']+B),(L2['off'],L2['size']+B)]
for rp in ('a/0/3/2','a/0/4/2'):
    _,do,ds=o.find(rp); a=o.fdata+do; R.append((a-2*B,ds+4*B))
R.append((o.fmeta-2*B,(o.fdata-o.fmeta)+2*B if o.fdata>o.fmeta else 8*B))
src=open(SRC,'rb'); dst=open(DST,'r+b'); n=0
for off,sz in R:
    src.seek(off); d=src.read(sz); dst.seek(off); dst.write(d); n+=sz
dst.flush(); dst.close()
dst=open(DST,'rb'); ok=all((src.seek(off),dst.seek(off),src.read(sz)==dst.read(sz))[2] for off,sz in R)
print('restaurado',n,'bytes em',len(R),'regioes; identico ao original:',ok)
