import struct
class GARC:
    def __init__(self, data):
        self.data = data
        magic, hs, endian, ver, cc, do, fs = struct.unpack_from('<4sIHHIII', data, 0)
        assert magic == b'CRAG', magic
        off = 24
        off += 4 if ver == 0x0400 else 12
        assert off == hs
        fm, fhs, ec, pad = struct.unpack_from('<4sIHH', data, off); assert fm == b'OTAF'
        fs0 = off; off += 12
        struct.unpack_from(f'<{ec}I', data, off); off = fs0 + fhs
        bm, bhs, fc = struct.unpack_from('<4sII', data, off); assert bm == b'BTAF'
        bs = off; off += 12
        ents = []
        for i in range(ec):
            bv, = struct.unpack_from('<I', data, off); off += 4
            subs = []
            for b in range(32):
                if bv & (1 << b):
                    s, e, l = struct.unpack_from('<III', data, off); off += 12
                    subs.append((s, e, l))
            ents.append(subs)
        off = bs + bhs
        im, ihs, ids = struct.unpack_from('<4sII', data, off); assert im == b'BMIF'
        self.data_offset = do; self.entries = ents; self.version = ver
    def __len__(self): return len(self.entries)
    def get(self, i, s=0):
        st, e, l = self.entries[i][s]
        return self.data[self.data_offset + st: self.data_offset + st + l]
