"""Leitor minimo de RomFS de um CCI/.3ds DESCRIPTOGRAFADO (NCSD->NCCH part0->IVFC L3).
Uso: python romfs_read.py <jogo.cci> ls <caminho>      (lista diretorio)
     python romfs_read.py <jogo.cci> get <caminho> <saida>
caminho ex.: a/0/4/2"""
import struct,sys
MU=0x200
class RomFS:
    def __init__(s,path):
        s.f=open(path,'rb'); f=s.f
        f.seek(0x100); assert f.read(4)==b'NCSD','nao e NCSD'
        f.seek(0x120); off,size=struct.unpack('<II',f.read(8)); ncch=off*MU
        f.seek(ncch+0x100); assert f.read(4)==b'NCCH'
        f.seek(ncch+0x188); fl=f.read(8); s.crypto = not (fl[7]&0x04)
        f.seek(ncch+0x1B0); ro,rs=struct.unpack('<II',f.read(8)); s.romfs=ncch+ro*MU
        f.seek(s.romfs); h=f.read(0x60); assert h[:4]==b'IVFC','romfs criptografada ou invalida'
        mh=struct.unpack_from('<I',h,8)[0]; l3bs=struct.unpack_from('<I',h,0x4C)[0]
        a=1<<l3bs; s.l3=s.romfs+((0x60+mh+a-1)//a)*a
        f.seek(s.l3); hd=struct.unpack('<10I',f.read(40))
        s.dmeta=s.l3+hd[3]; s.fmeta=s.l3+hd[7]; s.fdata=s.l3+hd[9]
    def _dir(s,o):
        s.f.seek(s.dmeta+o); p,sib,cd,cf,nh,nl=struct.unpack('<6I',s.f.read(24)); return sib,cd,cf,s.f.read(nl).decode('utf-16-le')
    def _file(s,o):
        s.f.seek(s.fmeta+o); p,sib,do,ds,nh,nl=struct.unpack('<IIQQII',s.f.read(32)); return sib,do,ds,s.f.read(nl).decode('utf-16-le')
    def children(s,d):
        _,cd,cf,_=s._dir(d); D={};F={}
        o=cd
        while o!=0xFFFFFFFF: sib,_,_,n=s._dir(o); D[n]=o; o=sib
        o=cf
        while o!=0xFFFFFFFF: sib,do,ds,n=s._file(o); F[n]=(do,ds); o=sib
        return D,F
    def resolve(s,path):
        d=0; parts=[x for x in path.split('/') if x]
        for i,p in enumerate(parts):
            D,F=s.children(d)
            if i==len(parts)-1 and p in F: return ('file',F[p])
            d=D[p]
        return ('dir',d)
if __name__=='__main__':
    r=RomFS(sys.argv[1]); cmd=sys.argv[2]; k,v=r.resolve(sys.argv[3])
    if cmd=='ls':
        D,F=r.children(v) if k=='dir' else ({},{})
        print('crypto?',r.crypto,'| dirs:',sorted(D)[:40],'| files:',sorted(F.items())[:40])
    elif cmd=='get':
        do,ds=v; r.f.seek(r.fdata+do); open(sys.argv[4],'wb').write(r.f.read(ds)); print('ok',ds,'bytes')
