"""Extrai arquivos do ExeFS de um CCI descriptografado e descomprime .code (BLZ)."""
import struct,sys
MU=0x200
def blz_decompress(d):
    d=bytearray(d)
    buf_top_bot,=struct.unpack_from('<I',d,len(d)-8); extra,=struct.unpack_from('<I',d,len(d)-4)
    hdr=d[-5]; enc_len=buf_top_bot&0xFFFFFF; hdr_len=buf_top_bot>>24
    out=bytearray(len(d)+extra); out[:len(d)]=d
    src=len(d)-hdr_len; dst=len(out); end=len(d)-enc_len
    while src>end:
        src-=1; flags=d[src]
        for b in range(8):
            if src<=end: break
            if flags&0x80:
                src-=2; v=d[src]|(d[src+1]<<8); disp=(v&0x0FFF)+3; ln=(v>>12)+3
                for _ in range(ln):
                    dst-=1; out[dst]=out[dst+disp]
            else:
                src-=1; dst-=1; out[dst]=d[src]
            flags=(flags<<1)&0xFF
            if dst<=end: break
    return bytes(out)
f=open(sys.argv[1],'rb'); f.seek(0x120); off,_=struct.unpack('<II',f.read(8)); ncch=off*MU
f.seek(ncch+0x1A0); eo,es=struct.unpack('<II',f.read(8)); ex=ncch+eo*MU
f.seek(ex); h=f.read(0x200)
for i in range(8):
    n=h[i*16:i*16+8].rstrip(b'\0').decode(); o,s=struct.unpack_from('<II',h,i*16+8)
    if n: print(n,hex(o),s)
    if n=='.code':
        f.seek(ex+0x200+o); c=f.read(s); dc=blz_decompress(c); open(sys.argv[2],'wb').write(dc); print('code.bin descomprimido:',len(dc))
