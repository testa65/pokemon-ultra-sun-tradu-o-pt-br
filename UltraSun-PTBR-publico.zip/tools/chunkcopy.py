import os,sys,time
src,dst=sys.argv[1],sys.argv[2]; budget=float(sys.argv[3]) if len(sys.argv)>3 else 150
tot=os.path.getsize(src); done=os.path.getsize(dst) if os.path.exists(dst) else 0
t=time.time(); CH=64<<20
with open(src,'rb') as f, open(dst,'r+b' if done else 'wb') as g:
    f.seek(done); g.seek(done)
    while done<tot and time.time()-t<budget:
        b=f.read(min(CH,tot-done)); g.write(b); done+=len(b)
print(done,tot,'%.1f%%'%(100*done/tot),'OK' if done==tot else 'PARCIAL')
