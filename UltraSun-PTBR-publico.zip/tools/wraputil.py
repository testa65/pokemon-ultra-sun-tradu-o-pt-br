"""Quebra de linha segura p/ textos do 3DS.
Palavra = sequencia sem espaco FORA de colchetes; tokens [VAR ..]/[WAIT n]/[~ n] ficam
colados no que estiver grudado neles (ex: "[VAR 0102(0000)]!", "[VAR BD06(0000)][VAR ..]",
"Moeda[VAR 1101(..)]s"). Nunca insere espaco novo nem quebra dentro de token."""
import re, overflow
WORD = re.compile(r'(?:\[[^\]]*\]|[^\s\[])+')
def words(chunk): return WORD.findall(chunk)
def wrap_to(chunk, W):
    ls=[]; cur=''
    for w in words(chunk):
        c = w if not cur else cur+' '+w
        if overflow.width(c) > W and cur: ls.append(cur); cur = w
        else: cur = c
    if cur or not ls: ls.append(cur)
    return ls
def fit(chunk, bud, maxl):
    W = bud
    while W < bud*2.2:
        ls = wrap_to(chunk, W)
        if len(ls) <= maxl: return '\\n'.join(ls)
        W += 0.4
    return '\\n'.join(wrap_to(chunk, bud))
def rewrap_line(l, bud, maxl):
    out=[]
    for p in re.split(r'(\\c|\\r)', l):
        if p in ('\\c','\\r'): out.append(p); continue
        out.append(fit(re.sub(r' +',' ', p.replace('\\n',' ')).strip(), bud, maxl))
    return ''.join(out)
