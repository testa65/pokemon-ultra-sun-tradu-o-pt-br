import struct
KEY_BASE=0x7C89; KEY_ADVANCE=0x2983; KEY_VARIABLE=0x0010; KEY_TERMINATOR=0x0000
KEY_TEXTRETURN=0xBE00; KEY_TEXTCLEAR=0xBE01; KEY_TEXTWAIT=0xBE02; KEY_TEXTNULL=0xBDFF
def _rot(v,n):
    v&=0xFFFF; return ((v<<n)|(v>>(16-n)))&0xFFFF
def _crypt(d,k):
    o=bytearray(len(d))
    for i in range(0,len(d),2):
        v=struct.unpack_from('<H',d,i)[0]; struct.pack_into('<H',o,i,v^k); k=_rot(k,3)
    return bytes(o)
def decode_textfile_full(data):
    ts,lc=struct.unpack_from('<HH',data,0); sdo,=struct.unpack_from('<I',data,0xC)
    meta=[];flags=[]
    for i in range(lc):
        off=struct.unpack_from('<i',data,i*8+sdo+4)[0]+sdo
        ln=struct.unpack_from('<h',data,i*8+sdo+8)[0]
        fl=struct.unpack_from('<H',data,i*8+sdo+10)[0]
        meta.append((off,ln)); flags.append(fl)
    k=KEY_BASE; out=[]
    for off,ln in meta:
        out.append(_parse(_crypt(data[off:off+ln*2],k))); k=(k+KEY_ADVANCE)&0xFFFF
    return out,flags
def decode_textfile(d): return decode_textfile_full(d)[0]
def _parse(dec):
    o=[];i=0;n=len(dec)
    while i<n:
        v=struct.unpack_from('<H',dec,i)[0]
        if v==KEY_TERMINATOR: break
        i+=2
        if v==KEY_VARIABLE:
            c=struct.unpack_from('<H',dec,i)[0];i+=2
            var=struct.unpack_from('<H',dec,i)[0];i+=2
            if var==KEY_TEXTRETURN:o.append('\\r')
            elif var==KEY_TEXTCLEAR:o.append('\\c')
            elif var==KEY_TEXTWAIT:
                t=struct.unpack_from('<H',dec,i)[0];i+=2;o.append(f'[WAIT {t}]')
            elif var==KEY_TEXTNULL:
                l=struct.unpack_from('<H',dec,i)[0];i+=2;o.append(f'[~ {l}]')
            else:
                a=[];r=c-1
                while r>0:
                    g=struct.unpack_from('<H',dec,i)[0];i+=2;a.append(f'{g:04X}');r-=1
                o.append(f'[VAR {var:04X}('+','.join(a)+')]' if a else f'[VAR {var:04X}]')
        elif v==ord('\n'):o.append('\\n')
        elif v==ord('\\'):o.append('\\\\')
        elif v==ord('['):o.append('\\[')
        else:o.append(chr(v))
    return ''.join(o)
def _enc_line(s):
    o=bytearray();i=0;n=len(s)
    while i<n:
        c=s[i]
        if c=='\\':
            i+=1;e=s[i];i+=1
            if e=='n':o+=struct.pack('<H',ord('\n'))
            elif e=='\\':o+=struct.pack('<H',ord('\\'))
            elif e=='[':o+=struct.pack('<H',ord('['))
            elif e=='r':o+=struct.pack('<HHH',KEY_VARIABLE,1,KEY_TEXTRETURN)
            elif e=='c':o+=struct.pack('<HHH',KEY_VARIABLE,1,KEY_TEXTCLEAR)
            else:raise ValueError(f'escape \\{e}')
        elif c=='[':
            cl=s.index(']',i+1);b=s[i+1:cl];i=cl+1;o+=_enc_var(b)
        else:
            o+=struct.pack('<H',ord(c));i+=1
    o+=struct.pack('<H',KEY_TERMINATOR); return bytes(o)
def _enc_var(b):
    p=b.split(' ',1);k=p[0];r=p[1] if len(p)>1 else ''
    if k=='WAIT':return struct.pack('<HHHH',KEY_VARIABLE,2,KEY_TEXTWAIT,int(r))
    if k=='~':return struct.pack('<HHHH',KEY_VARIABLE,2,KEY_TEXTNULL,int(r))
    if k=='VAR':
        pa=r.find('(')
        if pa<0: return struct.pack('<HHH',KEY_VARIABLE,1,int(r,16))
        var=int(r[:pa],16);args=r[pa+1:r.index(')')].split(',')
        vals=[KEY_VARIABLE,1+len(args),var]+[int(a,16) for a in args]
        return struct.pack(f'<{len(vals)}H',*vals)
    raise ValueError(b)
def encode_textfile(lines,flags=None):
    cnt=len(lines);sdo=0x10;enc=[];k=KEY_BASE
    for s in lines:
        e=_crypt(_enc_line(s),k);u=len(e)//2
        if len(e)%4==2:e+=b'\x00\x00'
        enc.append((e,u));k=(k+KEY_ADVANCE)&0xFFFF
    tsz=4+8*cnt;used=sum(len(e) for e,_ in enc);tot=tsz+used
    d=bytearray(sdo+tot)
    struct.pack_into('<HH',d,0,1,cnt);struct.pack_into('<I',d,4,tot)
    struct.pack_into('<I',d,8,0);struct.pack_into('<I',d,0xC,sdo);struct.pack_into('<I',d,sdo,tot)
    run=tsz
    for i,(e,u) in enumerate(enc):
        struct.pack_into('<i',d,i*8+sdo+4,run);struct.pack_into('<h',d,i*8+sdo+8,u)
        if flags is not None: struct.pack_into('<H',d,i*8+sdo+10,flags[i])
        d[sdo+run:sdo+run+len(e)]=e;run+=len(e)
    return bytes(d)
